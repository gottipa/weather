from weather_api.dto.weather_dto import WeatherDto

weather_dto = WeatherDto()


def get_weather_data(station_cd, report_dt):
    return weather_dto.fetch_weather_details(station_cd, report_dt)


def get_weather_stats_data(station_cd, year):
    return weather_dto.fetch_weather_stats_details(station_cd, year)
