from configparser import ConfigParser

import psycopg2

config: ConfigParser = None


def get_config():
    global config
    if config is None:
        config = ConfigParser()
        config.read("config.ini")
    return config


def get_connection():
    con = psycopg2.connect(
        host="localhost",
        database="suppliers",
        user="postgres",
        password="Abcd1234")
    return con


def run_sql(con, query):
    pass


print(config.sections())
