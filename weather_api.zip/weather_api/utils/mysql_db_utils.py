import datetime
from configparser import ConfigParser
import mysql.connector
import psycopg2

config: ConfigParser = None


def get_config():
    global config
    if config is None:
        config = ConfigParser()
        config.read("config.ini")
    return config


def get_config_section(section):
    return get_config()[section]


def get_connection(conn_name):
    # con = mysql.connector.connect(host='', port='', user='scott', database='employees')
    print(get_config().sections())
    print(dict(get_config()[conn_name]))
    con = mysql.connector.connect(**dict(get_config()[conn_name]))
    return con


def run_sql(conn_name, query):
    with get_connection(conn_name) as con:
        with con.cursor() as cursor:
            cursor.execute(query)
            return cursor_to_dict(cursor)


def cursor_to_dict(cursor):
    # Fetch all rows from the result set
    rows = cursor.fetchall()

    # Get the column names
    columns = [column[0] for column in cursor.description]

    # Convert rows to a list of dictionaries
    results = []
    for row in rows:
        data = {}
        for column, value in zip(columns, row):
            if type(value) == datetime.date:
                value=str(value)
            data[column] = value
        results.append(data)

    print(results)
    return results



