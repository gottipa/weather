from flask import Flask
from flask_restx import Api, Namespace
from weather_api.controllers.weather_controller import weather_controller

app = Flask(__name__)

api = Api(app,
          title="Weather API",
          description="API Service to provide weather data and analysis",
          version="1.0",
          doc="/swagger/",
          validate=True)

api.add_namespace(weather_controller)
app.run()
