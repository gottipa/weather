from flask_restx import  fields

weather_model = {
    'station_cd': fields.String(required=True, description='Station Code'),
    'record_dt': fields.String(required=True, description='Reported date'),
    'max_temp': fields.Integer(required=True, description='The maximum temperature for the day'),
    'min_temp': fields.Integer(required=True, description='The minimum temperature for the day'),
    'pcpn_amt': fields.Integer(required=True, description='The amount of precipitation for the day')
}

weather_stats_model = {
    'station_cd': fields.String(required=True, description='Station Code'),
    'record_year': fields.Integer(required=True, description='year'),
    'avg_max_temp': fields.Float(required=True, description='The maximum temperature for the day'),
    'avg_min_temp': fields.Float(required=True, description='The minimum temperature for the day'),
    'total_pcpn_amt': fields.Integer(required=True, description='The amount of precipitation for the day')
}