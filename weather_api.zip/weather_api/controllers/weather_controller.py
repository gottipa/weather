from flask_restx import Resource, Namespace
from weather_api.services import weather_service
from weather_api.models.weather import weather_model, weather_stats_model

weather_controller = Namespace("weather", path="/weather", description="Weather API Controller")

weather_request_parser = weather_controller.parser()
weather_request_parser.add_argument('station_cd', type=str, help='Weather Station code')
weather_request_parser.add_argument('report_dt', type=str, help='Metrics report date')

weather_request_parser = weather_controller.parser()
weather_request_parser.add_argument('station_cd', type=str, help='Weather Station code')
weather_request_parser.add_argument('year', type=str, help='Metrics report date')


weather_response_model = weather_controller.model("weather_response", weather_model)
weather_stats_response_model = weather_controller.model("weather_stats_response", weather_stats_model)


@weather_controller.route("/")
class Weather(Resource):
    @weather_controller.expect(weather_request_parser)
    @weather_controller.marshal_list_with(weather_response_model)
    def get(self):
        args = weather_request_parser.parse_args()
        station_cd = args.get('station_cd')
        report_dt = args.get('report_dt')
        return weather_service.get_weather_data(station_cd, report_dt)


@weather_controller.route("/stats")
class WeatherStats(Resource):
    @weather_controller.expect(weather_request_parser)
    @weather_controller.marshal_list_with(weather_stats_response_model)
    def get(self):
        args = weather_request_parser.parse_args()
        station_cd = args.get('station_cd')
        year = args.get('year')
        return weather_service.get_weather_stats_data(station_cd, year)
