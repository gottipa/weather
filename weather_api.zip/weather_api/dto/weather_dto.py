from weather_api.utils.mysql_db_utils import get_connection, run_sql


class WeatherDto:
    con = None
    config_section_name = 'WEATHER-DB'

    def __int__(self):
        pass

    def fetch_weather_details(self, station_cd, report_dt):
        filters = []
        filter_str  = ""
        if station_cd:
            filters.append(" station_cd='{}' ".format(station_cd))
        if report_dt:
            filters.append(" record_dt='{}' ".format(report_dt))
        if len(filters) > 0:
            filter_str = " where {}".format(" and ".join(filters))
        query = "select station_cd, record_dt, max_temp, min_temp, pcpn_amt from weather_details {}".format(filter_str)
        print(query)
        return run_sql(self.config_section_name, query)

    def fetch_weather_stats_details(self, station_cd, year):
        filters = []
        filter_str = ""
        if station_cd:
            filters.append(" station_cd='{}' ".format(station_cd))
        if year:
            filters.append(" record_year='{}' ".format(year))
        if len(filters) > 0:
            filter_str = " where {}".format(" and ".join(filters))
        query = "select * from weather_stats {}".format(filter_str)
        return run_sql(self.config_section_name, query)