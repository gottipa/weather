

# list all files in folder

# iterate each file and create pandas df  and also get station code from file name and add that as station_cd column

#

