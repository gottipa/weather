create database weather_db;

use weather_db;

create table if not exists weather_details (station_cd varchar(20),
record_dt Date,
max_temp int,
min_temp int,
pcpn_amt int,
create_tmst TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
unique(station_cd,
record_dt)
);


create table if not exists weather_stats (station_cd varchar(20),
record_year int,
avg_max_temp float,
avg_min_temp float,
total_pcpn_amt int,
create_tmst TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
unique(station_cd,
record_year)
);