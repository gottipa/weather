from flask import Flask
from flask_restx import Api
from flask_restx.apispec import APISpec


app = Flask(__name__)
api = Api(app)

# Load the OpenAPI specification file
spec = APISpec()
spec_path = '/path/to/your/openapi_specification.yaml'
spec.openapi = spec_path  # or spec.swagger = spec_path for Swagger files

# Create the API using the specification
api = spec.flask_restx(api)

# Run the Flask application
if __name__ == '__main__':
    app.run(debug=True)
